// config.js
const API_DOMAIN = 'http://89.116.110.51:9099/';
export default API_DOMAIN;
